export const AUTH_KEY = 'gymtrack_superadmin_auth';
export const GYMS_KEY = 'gymtrack_gyms_list';
// SUPER_ADMINS_KEY is removed as admin list is now managed in Supabase
