
'use client';

import { ArrowLeft, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export default function DataCenterPage() {
  const router = useRouter();

  return (
    <div className="flex h-full flex-col items-center justify-center">
      <div className="text-center">
        <Database className="mx-auto h-12 w-12 text-primary" />
        <h1 className="mt-4 text-2xl font-bold">Data Center</h1>
        <p className="mt-2 text-muted-foreground">
          <ArrowLeft className="inline-block h-4 w-4 mr-2" />
          Select a table from the sidebar to view and manage its data.
        </p>
      </div>
      <Button variant="outline" onClick={() => router.push('/dashboard')} className="mt-8">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Dashboard
      </Button>
    </div>
  );
}
