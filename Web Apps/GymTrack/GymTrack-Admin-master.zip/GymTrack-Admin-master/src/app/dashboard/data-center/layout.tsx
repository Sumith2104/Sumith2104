
'use client';

import { useState, type ReactNode } from 'react';
import Link from 'next/link';
import { Database, Table, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const tableMetadatas = [
  { name: 'super_admins', displayName: 'Super Admins' },
  { name: 'gyms', displayName: 'Gyms' },
  { name: 'members', displayName: 'Members' },
  { name: 'plans', displayName: 'Plans' },
  { name: 'check_ins', displayName: 'Check-ins' },
  { name: 'announcements', displayName: 'Announcements' },
  { name: 'messages', displayName: 'Messages' },
];

export default function DataCenterLayout({ children }: { children: ReactNode }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="flex flex-col min-h-[calc(100vh-200px)]">
      <header className="border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold tracking-tight flex items-center">
            <Database className="h-5 w-5 mr-2" />
            Database Tables
          </h2>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-controls="data-center-nav"
            aria-expanded={isMenuOpen}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            <span className="sr-only">Toggle menu</span>
          </Button>
        </div>
        <nav
          id="data-center-nav"
          className={cn(
            'mt-4 flex-col gap-1 md:flex md:flex-row md:flex-wrap md:gap-2',
            isMenuOpen ? 'flex' : 'hidden'
          )}
        >
          {tableMetadatas.map((table) => (
            <Link
              key={table.name}
              href={`/dashboard/data-center/${table.name}`}
              className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              onClick={() => setIsMenuOpen(false)} // Close menu on navigation in mobile
            >
              <Table className="h-4 w-4" />
              {table.displayName}
            </Link>
          ))}
        </nav>
      </header>
      <main className="flex-1 p-6">
        {children}
      </main>
    </div>
  );
}
