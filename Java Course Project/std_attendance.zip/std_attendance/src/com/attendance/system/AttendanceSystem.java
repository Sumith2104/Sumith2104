package com.attendance.system;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.multi.qrcode.QRCodeMultiReader;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Date;

import org.opencv.core.*;
import org.opencv.videoio.VideoCapture;

public class AttendanceSystem {
    static { System.loadLibrary(Core.NATIVE_LIBRARY_NAME); }

    public static void main(String[] args) {
        String excelFilePath = "attendance.xlsx";

        try {
            createExcelIfNotExists(excelFilePath);
            String studentRegNumber = scanBarcodeFromCamera();
            
            if (studentRegNumber != null) {
                updateAttendanceExcel(excelFilePath, studentRegNumber);
                System.out.println("✔ Attendance marked for: " + studentRegNumber);
            } else {
                System.out.println("❌ No barcode detected.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ Create Excel File If It Doesn't Exist
    public static void createExcelIfNotExists(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Attendance");

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Student ID");
            headerRow.createCell(1).setCellValue("Timestamp");

            try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
                workbook.write(fileOut);
            }
            workbook.close();
            System.out.println("📄 Created new attendance file: " + filePath);
        }
    }

    // ✅ Scan Barcode from Webcam
    public static String scanBarcodeFromCamera() {
        VideoCapture camera = new VideoCapture(0);
        if (!camera.isOpened()) {
            System.out.println("❌ Error: Camera not found.");
            return null;
        }

        Mat frame = new Mat();
        camera.read(frame);
        BufferedImage image = matToBufferedImage(frame);
        camera.release();

        return decodeBarcode(image);
    }

    // ✅ Convert Mat (OpenCV Image) to BufferedImage
    public static BufferedImage matToBufferedImage(Mat mat) {
        int width = mat.width(), height = mat.height(), channels = mat.channels();
        byte[] sourcePixels = new byte[width * height * channels];
        mat.get(0, 0, sourcePixels);

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
        image.getRaster().setDataElements(0, 0, width, height, sourcePixels);
        return image;
    }

    // ✅ Decode Barcode from BufferedImage
    public static String decodeBarcode(BufferedImage image) {
        try {
            LuminanceSource source = new BufferedImageLuminanceSource(image);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            Result result = new QRCodeMultiReader().decode(bitmap);
            return result.getText();
        } catch (Exception e) {
            System.out.println("❌ Barcode scanning failed.");
            return null;
        }
    }

    // ✅ Update Attendance Excel
    public static void updateAttendanceExcel(String filePath, String studentId) throws IOException {
        FileInputStream fileIn = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fileIn);
        Sheet sheet = workbook.getSheet("Attendance");

        int lastRow = sheet.getLastRowNum();
        Row row = sheet.createRow(lastRow + 1);
        row.createCell(0).setCellValue(studentId);
        row.createCell(1).setCellValue(new Date().toString());

        fileIn.close();

        try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
            workbook.write(fileOut);
        }
        workbook.close();
        System.out.println("📌 Attendance updated in Excel.");
    }
}
